-- --------------------------------------------------------
-- Host:                         127.0.0.1
-- Server version:               8.0.24 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             11.2.0.6213
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping structure for table flex.api
CREATE TABLE IF NOT EXISTS `api` (
  `link` text COLLATE utf8_bin
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb3 COLLATE=utf8_bin;

-- Dumping data for table flex.api: ~0 rows (approximately)
/*!40000 ALTER TABLE `api` DISABLE KEYS */;
INSERT INTO `api` (`link`) VALUES
	('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');
/*!40000 ALTER TABLE `api` ENABLE KEYS */;

-- Dumping structure for table flex.users
CREATE TABLE IF NOT EXISTS `users` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(230) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `status` varchar(30) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'inactive',
  `roles` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT 'user',
  `dlimit` int DEFAULT '0',
  `ip` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `regAt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=729 DEFAULT CHARSET=utf8mb3 COLLATE=utf8_unicode_ci;

-- Dumping data for table flex.users: 2 rows
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` (`id`, `username`, `password`, `status`, `roles`, `dlimit`, `ip`, `regAt`) VALUES
	(1, 'hyper22', 'kavini@2004', 'active', 'admin', 0, 'fullbinsIP', '2022-06-26 21:23:15'),
	(728, 'Ashinsana', 'OFFICIALBINS-fd3f10045eeced96323ece6bbf5fac75', 'active', 'user', 0, 'fullbinsIP', '2022-06-26 22:13:09');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
