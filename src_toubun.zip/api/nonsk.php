
 <?php
 
 session_start();
 if (!isset($_SESSION['username1'])) {
  echo '<p class="uk-margin-small-top">user not logged </p>';
   }else{
  
 error_reporting(0);
 set_time_limit(0);
 error_reporting(0);
 date_default_timezone_set('America/Buenos_Aires');
 
 $amount = 0.8;
 $lista = $_GET['lista'];
 if(isset($_GET['amount'])){
 $amount = $_GET['amount'];
 }

//  $ch = curl_init();
// curl_setopt($ch, CURLOPT_URL, 'https://lookup.binlist.net/'.$cc.'');
// curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
// curl_setopt($ch, CURLOPT_HTTPHEADER, array(
// 'Host: lookup.binlist.net',
// 'Cookie: _ga=GA1.2.549903363.1545240628; _gid=GA1.2.82939664.1545240628',
// 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8'));
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// curl_setopt($ch, CURLOPT_POSTFIELDS, '');
// $fim = curl_exec($ch); 
// $emoji = GetStr($fim, '"emoji":"', '"'); 
// if(strpos($fim, '"type":"credit"') !== false){
// }
// curl_close($ch);

// $ch = curl_init();
// $bin = substr($cc, 0,6);
// curl_setopt($ch, CURLOPT_URL, 'https://binlist.io/lookup/'.$bin.'/');
// curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
// curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
// curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
// curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
// $bindata = curl_exec($ch);
// $binna = json_decode($bindata,true);
// $brand = $binna['scheme'];
// $country = $binna['country']['name'];
// $type = $binna['type'];
// $bank = $binna['bank']['name'];
// curl_close($ch);

    
 
 $Api = $_SESSION["api"];
 
 $json_url = file_get_contents("$Api?lista=$lista?amount=$amount");
 
 



if (preg_match("/Charged! /i", $json_url)){
$status = '#CVV';
$resmsg = $cur.$amount.' Donation Successfull ! ';
echo ' <p class="uk-margin-small-top">'.$status.' : '.$resmsg.' : ' . $lista . ' : '.$country.' : <a class="receipt" href="'.$receipturl.'">Get Receipt</a> - </p>';
exit;
}elseif (preg_match("/Insufficient /i", $json_url)){
$status = '#CVV';
$resmsg = 'Insufficient';
}elseif (preg_match("/Incorrect cvc /i", $json_url)) {
    $status = '#CCN';
$resmsg = 'Incorrect cvc';

}
elseif (preg_match("/rate_limit /i", $json_url)){
  $status = 'SK KEY';
  $resmsg = 'rate_limit';
  }
elseif (preg_match("/test_mode /i", $json_url)){
$status = 'SK KEY';
$resmsg = 'test_mode';
}

elseif (preg_match("/testmode_charges_only /i", $json_url)){
$status = 'SK KEY';
$resmsg = 'testmode_charges_only';
}

elseif(preg_match("/Invalid Request /i", $json_url)) {
$status = 'SK KEY';
$resmsg = 'Invalid Request';
}

elseif(preg_match("/sk key dead /i", $json_url)){
$status = 'SK KEY';
$resmsg = 'SK KEY DEAD';
}

elseif(preg_match("/api_key_expired /i", $json_url)){
$status = 'SK KEY';
$resmsg = 'api_key_expired';
}

else {
$status = 'Declined';
$resmsg = 'DEAD';
}

    echo '<p class="uk-margin-small-top">'.$status.' | '.$resmsg.' | ' . $lista . ' | '.$d_code3.  ' </p>';


curl_close($ch);
ob_flush();
   }
?>