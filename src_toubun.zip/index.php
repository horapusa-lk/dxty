<?php

header("location: ./v1");
// Crafted by Hyper Community 
// Made with Php && Boostrap

