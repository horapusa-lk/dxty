<span>account banned</span>

<script>
    window.location = "../";
</script>