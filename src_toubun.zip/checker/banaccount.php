<?php

session_start();
require "../config.php";


// $sel = "UPDATE users SET `status`='inactive' WHERE password='".$_SESSION["access"]."'";
   
    
if ($connect->query($sel) === TRUE) {
   
   $txt = "User '".$_SESSION["username1"]."' Try to inspect";
   $msg  = file_get_contents("https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=5126439799&text=$txt"); 
          
   echo "1";
   session_destroy();
} 




?>