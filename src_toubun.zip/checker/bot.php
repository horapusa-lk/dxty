<?php

///////////===[Bot Functions]===///////////
function bot($method){
    
    $url = "https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/".$method;
   
}

function sendMessage($chat_id,$text,$keyboard){
	bot('sendMessage',[
	'chat_id'=>$chat_id,
	'text'=>$text,
	'reply_markup'=>$keyboard]);
}



?>