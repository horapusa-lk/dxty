<?php
require "connection.php";
define('BOT_TOKEN', '5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ');
define('API_URL', 'https://api.telegram.org/bot' . BOT_TOKEN . '/');
function processMessage($message)
{
    // processa a mensagem recebida
    $message_id = $message['message_id'];
    $u =  $message['from']['username'];
    $chat_id = $message['chat']['id'];
    if (isset($message['text'])) {

        $text = $message['text']; //texto recebido na mensagem

        if (strpos($text, "/start") === 0) {

            sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => 'Hi ! ' . $message['from']['first_name'] .
                '  Bot Started successfully! ✅

        To Buy - /buy
        To see commands - /cmds'));
        } else if (strpos($text, "/buy") !== false) {

            sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => "✅ Contact @Im_kz_T to buy checker"));
        } else if (strpos($text, "/cmds") !== false) {


            sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => "Bot Commands ✅

            /buy - To Buy
            /chk - Stripe Charge + Refund 1$
            /cmds - To check cmds
            /status - active
           
           "));
        } else if (strpos($text, "/status") !== false) {

            $msg = $message['text'];
            $result = explode(' ', $msg);
            $res = $result["1"];



            sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => "Active ✅"));
        } else if (strpos($text, "/acuserx") !== false) {

            $msg = $message['text'];
            $result = explode(' ', $msg);
            $res = $result["1"];

            $fx = Database::search("SELECT * FROM `users` WHERE `password`='".$res."'");
            $df = $fx->fetch_assoc();
            if ($fx->num_rows == 0) {
                sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => "User not found !"));
            } else {
                Database::iud("UPDATE `users` SET `status`='active' WHERE `password`='" . $res . "'");
                sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => "User '" . $res . "' added !"));
            }
        } else if (strpos($text, "/chk") !== false) {


            $msg = $message['text'];
            $result = explode(' ', $msg);
            $res = $result["1"];

            $json_url = file_get_contents("YOUR_API?lista=$res");
            $s1 = explode('>', $json_url);
            $s2 = $s1["1"];

            $result = explode('|', $s2);

            $status = $result["0"];

            $type =  $result["1"];

            $cardnum =  $result["2"];
            $mm2 =  $result["3"];
            $yy2 =  $result["4"];
            $cvv2 =  $result["5"];
            $bin =  $result["6"];
            $binex = explode('<', $bin);
            $gbin = $binex["0"];

            $cardDetails = $cardnum . "|" . $mm2 . "|" . $yy2 . "|" . $cvv2;

            $dat = "null";

            if (preg_match("/DEAD/i", $json_url)) {
                $dat =  "  CC ➟ " . $cardDetails . "
    STATUS ➟ ❌ " . $type . "
    MSG ➟ " . $gbin . "
    CHECKED BY ➟ " . $message['from']['first_name'] . " 
    BOT BY ➟ @Im_kz_T
    ";
            } else if (preg_match("/receipt/i", $json_url)) {


                $c1 = explode('|', $json_url);
                $cardN = $c1["2"];
                $cmm = $c1["3"];
                $cyy = $c1["4"];
                $ccvv = $c1["5"];
                $cc = $cardN . "|" . $cmm . "|" . $cyy . "|" . $ccvv;

                $dat =  "  CC ➟ " . $cc . "
      STATUS ➟ ✅ Approved

      MSG ➟ Donation Successful! 1$ 🔥

      CHECKED BY ➟ " . $message['from']['first_name'] . " 💝
      BOT BY ➟ @Im_kz_T
      ";
            }  else if (preg_match("/charged/i", $json_url)) {


                $c1 = explode('|', $json_url);
                $cardN = $c1["2"];
                $cmm = $c1["3"];
                $cyy = $c1["4"];
                $ccvv = $c1["5"];
                $cc = $cardN . "|" . $cmm . "|" . $cyy . "|" . $ccvv;

                $dat =  "  CC ➟ " . $cc . "
      STATUS ➟ ✅ Approved

      MSG ➟ Donation Successful! 1$ 🔥

      CHECKED BY ➟ " . $message['from']['first_name'] . " 💝
      BOT BY ➟ @Im_kz_T
      ";
            } else if (preg_match("/#CVV/i", $json_url)) {
                $dat =  "  CC ➟ " . $cardDetails . "
      STATUS ➟ ✅ Approved
      MSG ➟ Card Approved CCN/CCV Live
      CHECKED BY ➟ " . $message['from']['first_name'] . " 💝
      BOT BY ➟ @Im_kz_T
      ";
            } else if (preg_match("/#CCN/i", $json_url)) {
                $dat =  "  CC ➟ " . $cardDetails . "
      STATUS ➟ ✅ Approved
      MSG ➟ Card Approved CCN/CCV Live
      CHECKED BY ➟ " . $message['from']['first_name'] . " 💝
      BOT BY ➟ @Im_kz_T
      ";
            } else if (preg_match("/insufficient/i", $json_url)) {

                $c1 = explode('|', $json_url);
                $cardN = $c1["2"];
                $cmm = $c1["3"];
                $cyy = $c1["4"];
                $ccvv = $c1["5"];
                $cc = $cardN . "|" . $cmm . "|" . $cyy . "|" . $ccvv;

                $dat =  "  CC ➟ " . $cc . "
      STATUS ➟ ✅ Approved
      MSG ➟ insufficient funds
      CHECKED BY ➟ " . $message['from']['first_name'] . " 💝
      BOT BY ➟ @Im_kz_T
      ";
            } else if (preg_match("/Invalid/i", $json_url)) {
                $dat =  " 
      STATUS ➟ Something went wrong 😐
      MSG ➟ We are working on it 😉
      CHECKED BY ➟ " . $message['from']['first_name'] . " 💝
      BOT BY ➟ @Im_kz_T
      ";
            }




            // $itens = $json_str['vidInfo'];
            // $dlink = print_r(($itens[0]['dloadUrl']), true);
            // $dlink = "https:" . $dlink;
            sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => "$dat"));
        } else {
            sendMessage("sendMessage", array('chat_id' => $chat_id, "text" => 'Hi ! ' . $message['from']['first_name'] .
                "Press /cmds for command"));
        }
    }
}
function sendMessage($method, $parameters)
{
    $options = array(
        'http' => array(
            'method'  => 'POST',
            'content' => json_encode($parameters),
            'header' =>  "Content-Type: application/json\r\n" .
                "Accept: application/json\r\n"
        )
    );
    $context  = stream_context_create($options);
    file_get_contents(API_URL . $method, false, $context);
}
$update_response = file_get_contents("php://input");
$update = json_decode($update_response, true);
if (isset($update["message"])) {
    processMessage($update["message"]);
}
