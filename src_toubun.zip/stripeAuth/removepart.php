<?php
session_start();
$cd = $_POST["cd"];

$variable = $cd;

$text =  str_replace(" #LIVE ","\n",$variable);
$final =  str_replace("#LIVE ","",$text);

$data = preg_replace('/\<br(\s*)?\/?\>/i', "\n", $final);

  
$_SESSION["ccs"] = $data;

?>


