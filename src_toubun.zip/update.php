<?php
require "config.php";

$pass = $_GET["p"];
$date = $_GET["d"];

$np  = urldecode($pass);
$nd = urldecode($date);


   
    $sel = "UPDATE users SET expire = '".$nd."' WHERE password = '".$np."'";
   
    
    if ($connect->query($sel) === TRUE) {
       
    echo $pass;
    }




?>