<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="shortcut icon" type="image/png" href="https://telegra.ph/file/815a196e0c6f1154d29f5.jpg" >
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css" />
    <link rel="stylesheet" href="../css/hyper.css?v=1.1" />
    <script src="../js/uikit.js"></script>
    <?php
  include "../config.php";
  session_start();
  $userLogged = false;
  $myip = $hyper->get_user_ip();
  if(isset($_SESSION['username1'])){
    $userLogged = true;
      header("location: ./dashboard?source_utm=create_user");
    
  }
  
  $message ="";
  if(isset($_POST['create_token'])){
    $username = $_POST['username'];

    $sanitized_userid = mysqli_real_escape_string($connect, $username);
   
    $sel = "UPDATE users SET ip='".$myip."' WHERE password='".$sanitized_userid."'";
   
    
    if ($connect->query($sel) === TRUE) {
       
        $hyper->redirect_to("index.php");
    } else {
      header("location: newip.php");
      
    }
}

    $connect->close();

  
  ?>
</head>

<body>

<?php include"./include/header.php"; ?>

<div class="uk-section uk-section-muted">
  <div class="uk-container">
    <div class="uk-background-default uk-border-rounded uk-box-shadow-small">
      <div class="uk-container uk-container-xsmall uk-padding-large">
        <article class="uk-article">
          <h1 class="uk-article-title">Update ip</h1>
          <div class="uk-article-content">
              <?php
              if ($hyper->get_parameter("message", "ip_already_exists")) {
                echo $hyper->create_notice_bar(
                    array(
                        "text" => "You can't create multiple account.",
                        "css" => "text-danger",
                        "ele"=>"p"
                    )
                );
            } else if ($hyper->get_parameter("message", "user_err")) {
                echo $hyper->create_notice_bar(
                    array(
                        "text" => "Unable to create new account.",
                        "css" => "text-danger",
                        "ele"=>"p"
                    )
                );
            }
              ?>
            <p class="uk-text-lead uk-text-muted">Already have access code login<a href="./?_login=create_session" class="access_link"> here</a></p>
            <form class="uk-form-stacked uk-margin-medium-top" method="POST" action="">
              <div class="uk-margin-bottom">
                <label class="uk-form-label" for="name">please enter your password</label>
                <div class=" hyper_login uk-form-controls">
                  <input id="name" class="hyper_input uk-input uk-border-rounded" name="username" 
                  type="text" placeholder="IM_KZ_T-xxxxx" required>
                </div>
              </div>
              <div class="uk-text-center">
                <input class="uk-button uk-button-primary uk-border-rounded" name="create_token" type="submit" value="Update ip">
              </div>
            </form>
          </div>
        </article>
      </div>
    </div>
  </div>
</div>


<?php include './include/footer.php'; ?>

<script src="../js/awesomplete.js"></script>
<script src="../js/custom.js"></script>


</body>

</html>