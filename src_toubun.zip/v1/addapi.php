<?php
$api = $_POST["api"];

require "../config.php";

$sel = "UPDATE api set link = '".$api."'";
   
    
if ($connect->query($sel) === TRUE) {
    echo "added";
}else{
    echo "error";
}
