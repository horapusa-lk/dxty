<?php
session_start();
$d = new DateTime();
$tz = new DateTimeZone("Asia/Colombo");
$d->setTimezone($tz);
$date = $d->format("Y-m-d H:i:s");
require "../config.php";
$sel1 = "SELECT * From users where password='".$_SESSION["access"]."' and status='inactive'";
$sel1Done =mysqli_query($connect, $sel1);

    if(mysqli_num_rows($sel1Done) ==1){
session_destroy();
?>
<script>window.location = "../";</script>
<?php
        }
  $sel2 = "SELECT * FROM users WHERE `password`='".$_SESSION["access"]."' AND `expire` <'".$date."'";
$sel2Done =mysqli_query($connect, $sel2);

    if(mysqli_num_rows($sel2Done) ==1){
session_destroy();
?>
<script>window.location = "../";</script>
<?php
        }

    ?>



<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dashboard</title>
    <link rel="shortcut icon" type="image/png" href="https://telegra.ph/file/815a196e0c6f1154d29f5.jpg">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css" />
    <link rel="stylesheet" href="../css/hyper.css?v=1.7" />
    <script src="../js/uikit.js"></script>
    <?php

    $userLogged = false;
    $isAdmin = false;
    $is_active = false;
    $access_tok = 'null';
    if (isset($_SESSION['username1'])) {
        $userLogged = true;
        if ($_SESSION['roles'] === "admin") {
            $isAdmin = true;
$txt = "User '".$_SESSION["username1"]."' Admin Logged";
   $msg  = file_get_contents("https://api.telegram.org/bot5410766721:AAGpGY4dD4iJXkFU-mqzH2Ls6PG0h3AVYuQ/sendMessage?chat_id=5126439799&text=$txt"); 
        
        }
        if ($_SESSION['status'] === 'active') {
            $is_active = true;
        }
        if ($_SESSION['access'] !== null) {
            $access_tok = $_SESSION['access'];
        }
    }
    if ($userLogged !== true) {
        return header("location: ./?message=user_not_logged");
    }


    ?>
</head>

<body>

    <?php include "./include/header.php"; ?>

    <div class="uk-section uk-section-muted">
        <div class="uk-container">
            <div class="uk-background-default uk-border-rounded uk-box-shadow-small">
                <div class="uk-container uk-container-xsmall uk-padding-large">
                    <article class="uk-article">
                        <h1 class="uk-article-title">IM_KZ_T
                            <p style="float:right;">
                                <label class="switch">
                                    <input type="checkbox" onclick="darkLight()" id="checkBox">
                                    <span class="slider"></span>
                                </label>
                            </p>
                        </h1>
                        <div class="uk-article-content">
                            <?php if ($_SESSION['roles'] === 'admin') { ?>
                                <p class="uk-text-lead uk-text-muted">Manage your gates & settings <a href="./gates?utm_source=dashboard" class="access_link">here</a></p>
                               
                                <!-- card one  -->
                                <!-- <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="./gates"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> Manage Gates</a> </h3>
                                            <span class="tag_required">Manage Gates</span>

                                        </div>
                                    </div>
                                </div> -->
                                <!-- card one  -->
                               

                                <!-- card one  -->
                                <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="./appatahikena_pending_eka.php"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> Pending Users</a></h3>
                                            <span class="tag_active">Manage Users</span>

                                        </div>
                                    </div>
                                </div>

                                 <!-- card one  -->
                                 <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="appatahikena_active?_utm_source=pending"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> Active Users</a></h3>
                                            <span class="tag_active">Manage Users</span>

                                        </div>
                                    </div>
                                </div>

                                    <!-- card one  -->
                                    <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="./api_ekachange_karana_eka.php"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> Manage API</a></h3>
                                            <span class="tag_active">Change API</span>

                                        </div>
                                    </div>
                                </div>

                            <?php
                            } else  if ($is_active === true) {

                                include("./include/user_dash.php");
                            } else {

                            ?>
                                  <script>
                                window.location = "BuySubscription.php";
                              </script>
                            <?php
                            } ?>


                        </div>
                    </article>
                </div>
            </div>
        </div>
    </div>


    <?php include './include/footer.php'; ?>

    <script src="../js/awesomplete.js"></script>
    <script src="../js/custom.js"></script>


</body>

</html>