<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="shortcut icon" type="image/png" href="https://telegra.ph/file/815a196e0c6f1154d29f5.jpg">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css" />
    <link rel="stylesheet" href="../css/hyper.css?v=1.1" />
    <script src="../js/uikit.js"></script>
</head>

<body>

    <?php
    require "../config.php";
    session_start();
    $userLogged = false;
    $isAdmin = false;
    $is_active = false;
    $access_tok = 'null';
    if (isset($_SESSION['username1'])) {
        $userLogged = true;
        if ($_SESSION['roles'] === "admin") {
            $isAdmin = true;
        }
        if ($_SESSION['status'] === 'active') {
            $is_active = true;
        }
        if ($_SESSION['access'] !== null) {
            $access_tok = $_SESSION['access'];
        }
    }
    if ($userLogged !== true) {
        return header("location: ./?message=user_not_logged");
    }

    include "./include/header.php";

    ?>

    <div class="uk-section uk-section-muted">
        <div class="uk-container">
            <div class="uk-background-default uk-border-rounded uk-box-shadow-small">
                <div class="uk-container uk-container-xsmall uk-padding-large">
                    <article class="uk-article">
                        <h1 class="uk-article-title">Change API</h1>
                        <div class="uk-article-content">
                            
                            <p class="uk-text-lead uk-text-muted">Your current key is <a href="#" class="access_link">


         <?php
                                 $sel1 = "SELECT * From api";
                                 $sel1Done =mysqli_query($connect, $sel1);
$d=$sel1Done->fetch_assoc();
 
$string = substr($d["link"], 0, 15);
echo $string;
                                    ?>
                                </a></p>
                            <div class="uk-form-stacked uk-margin-medium-top" >
                                <div class="uk-margin-bottom">
                                    <label class="uk-form-label" for="name">Enter API key</label>
                                    <div class=" hyper_login uk-form-controls">

                                    <select style="background-color: black;border: none;" class="hyper_input uk-input uk-border-rounded text-white" name="" id="api">
                                        <option value="1">Gunnu (1)</option>
                                        <option value="2">SRF (2)</option>
                                        <option value="3">Astrian (3)</option>
                                        <option value="4">UCHIHA (4)</option>
                                        <option value="5">Hacking-Info(5)</option>
                                        <option value="6">ZNC (6)</option>
<option value="7">Kingslaver (7)</option>
 <option value="8">DEADANONS (8)</option>
                                    </select>
                                        <!-- <input id="api" class="hyper_input uk-input uk-border-rounded" name="sk_input" type="text" placeholder="Enter API number here" required> -->
                                    </div>
                                </div>
                                <div class="uk-text-center">
                                    <input onclick="addsk()" class="uk-button uk-button-primary uk-border-rounded" name="addsk" type="submit" value="Add new sk">
                                </div>
</div>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </div>


    <?php include './include/footer.php'; ?>

    <script src="../js/awesomplete.js"></script>
    <script src="../js/custom.js"></script>


</body>

</html>