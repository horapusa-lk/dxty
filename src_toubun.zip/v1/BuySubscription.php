<?php
session_start();
include "../config.php";





if($_SESSION['status'] = 'inactive'){
    $sel1 = "SELECT * From users where password='".$_SESSION["access"]."' AND status='active'";
    $sel1Done =mysqli_query($connect, $sel1);
    
        if(mysqli_num_rows($sel1Done) == 1){
       
            $_SESSION['status'] = 'active';
    
            ?>
    <script>
        window.location ="dashboard.php";
    </script>
            <?php
        }
    ?>
?>



<!DOCTYPE html>
<html lang="en-gb" dir="ltr">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="shortcut icon" type="image/png" href="https://telegra.ph/file/815a196e0c6f1154d29f5.jpg">
    <link href="https://fonts.googleapis.com/css?family=Muli:300,400,500,600,700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../css/main.css" />
    <link rel="stylesheet" href="../css/hyper.css?v=1.7" />
    <script src="../js/uikit.js"></script>
    <?php
   


    ?>
</head>

<body>

    <?php include "./include/header.php"; ?>

    <div class="uk-section uk-section-muted">
        <div class="uk-container">
            <div class="uk-background-default uk-border-rounded uk-box-shadow-small">
                <div class="uk-container uk-container-xsmall uk-padding-large">
                    <article class="uk-article">
                        <h1 class="uk-article-title">Purchase Subscription
                          
                        </h1>
                        <div class="uk-article-content">
                          
                         <!-- card one  -->
                         <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="waitingpayment.php?pack=0"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> 1 HOUR</a></h3>
                                            <span class="tag_active">0.5 USD ($)</span>

                                        </div>
                                    </div>
                                </div>
                           

                                <!-- card one  -->
                                <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="waitingpayment.php?pack=1"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> 1 Day</a></h3>
                                            <span class="tag_active">1 USD ($)</span>

                                        </div>
                                    </div>
                                </div>

                                 <!-- card one  -->
                                 <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="waitingpayment.php?pack=2"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> 3 Day</a></h3>
                                            <span class="tag_active">4 USD ($)</span>

                                        </div>
                                    </div>
                                </div>
                           
                            
                                 <!-- card one  -->
                                 <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                                    <a class="uk-position-cover" href="waitingpayment.php?pack=3"></a>

                                    <div class="uk-article-meta uk-flex uk-flex-middle">

                                        <div class="uk-border-circle uk-avatar-small s_logo"></div>
                                        <div>
                                            <h3><a href=""> 1 WEEK</a></h3>
                                            <span class="tag_active">6 USD ($)</span>

                                        </div>
                                    </div>
                                </div>
                           
                          


                        </div>

                        <p class="uk-text-lead uk-text-muted">Here is your account token (keep it in safe place).</p>
                                <input type="text" class="uk-form-controls access_input" value="<?php echo $_SESSION["access"]; ?>" readonly>

                    </article>
                </div>
            </div>
        </div>
    </div>

   
    <?php include './include/footer.php'; ?>

    <script src="../js/awesomplete.js"></script>
    <script src="../js/custom.js"></script>


</body>

</html>

<?php

}else{
    ?>
<script>
    window.location = "dashboard.php";
</script>
    <?php
}
?>
