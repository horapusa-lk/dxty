<h3 class="mtitle" > Your account status is <span class="tag_success">Approved </span>&nbsp;🎉</h3>
        
                <p class="uk-text-lead uk-text-muted">Congratulations!! your account account has been approved by our admins.</p>
    
              

             
              <!-- card two  -->
              <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="../checker"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                  <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> Non Sk</a></h3>
                   <span class="tag_active">Active</span>
                    
                  </div>
                </div>
              </div>

        <!-- card three  -->
        <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="../vbv"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                 
                <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> VBV Checker</a></h3>
                   <span class="tag_active">active</span> 
                   
                  </div>
                </div>
              </div>
              <!-- card one  -->
<div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="./skchecker"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                 
                <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> Sk Based</a></h3>
                   <span class="tag_active">active</span> 
                   
                  </div>
                </div>
              </div>

               <!-- card two  -->
      <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="../stripeAuth"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                  <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> Stripe Auth</a></h3>
                   <span class="tag_active">Inactive</span>
                    
                  </div>
                </div>
              </div>


       


              <p class="uk-text-lead uk-text-muted">Here is your account token [keep it in safe place]</p>
                <input type="text" class="uk-form-controls access_input" value="<?php echo $access_tok; ?>" readonly>