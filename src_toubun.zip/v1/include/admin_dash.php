<h3 class="mtitle" > Hello, <span class="tag_success">Admin</span></h3>
        
                <p class="uk-text-lead uk-text-muted">Back to dashboard <a href="./dashboard?utm_source=gates" class="access_link">here</a></p>
       <!-- card two  -->
       <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="../checker"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                  <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> Non Sk</a></h3>
                   <span class="tag_active">Active</span>
                    
                  </div>
                </div>
              </div>

        <!-- card three  -->
        <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="../vbv"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                 
                <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> VBV Checker</a></h3>
                   <span class="tag_active">active</span> 
                   
                  </div>
                </div>
              </div>
              <!-- card one  -->
<div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="./skchecker"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                 
                <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> Sk Based</a></h3>
                   <span class="tag_active">active</span> 
                   
                  </div>
                </div>
              </div>

               <!-- card two  -->
      <div class="uk-card uk-card-category hyper_mt uk-card-default uk-card-hover uk-card-body uk-inline uk-border-rounded uk-width-1-1">
                <a class="uk-position-cover" href="../stripeAuth"></a>
               
                <div class="uk-article-meta uk-flex uk-flex-middle">
                  <div class="uk-border-circle uk-avatar-small s_logo" ></div>
                  <div>
                   <h3><a href=""> Stripe Auth</a></h3>
                   <span class="tag_active">Inactive</span>
                    
                  </div>
                </div>
              </div>

