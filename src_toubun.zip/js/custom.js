function addsk() {
    var api = document.getElementById("api").value;
    var f = new FormData();
    f.append("api", api);
    var r = new XMLHttpRequest();
    r.onreadystatechange = function() {
        if (r.readyState == 4) {
            var text = r.responseText;


            alert(text);
            window.location.reload();

        }
    };
    r.open("POST", "addapi.php", true);
    r.send(f);


}