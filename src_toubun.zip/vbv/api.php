<?php


$lista = $_GET['lista'];
   

$json_url = file_get_contents("https://privatechecker.tech/3d.php?lista=$lista");

$th = urlencode($json_url);


//=================== [ RESPONSES ] ===================//

if (preg_match("/Lookup Enrolled/i", $json_url)){
    echo '#DIE</span>'.$json_url.'</span><br>';
   

    
    
}

else {
    
    echo '</span> '.$json_url.'</span><br>';
 
   
      
}

ob_flush();
?>