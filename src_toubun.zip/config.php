<?php

use Hyper\Hyper;

$host = "db-mysql-nyc3-56419-do-user-10939254-0.b.db.ondigitalocean.com";
$username = "doadmin";
$password = "AVNS_pc52p_1LDYdq-3YCqo-"; 
$database = "pro_checker_op";
$con_status = "active";
$port = "25060";

$connect = new mysqli($host, $username, $password, $database,$port);
// Checking Connection
if (mysqli_connect_errno()) {
    printf("Database connection failed: %s\n", mysqli_connect_error());
    exit();
} else {
    $con_status = "active";
}

require "v1/hyper.php";

$hyper = new Hyper($connect, "SQL");